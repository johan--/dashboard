XLSX.parseZip = parse_zip;
XLSX.read = readSync;
XLSX.readFile = readFileSync;
XLSX.write = writeSync;
XLSX.writeFile = writeFileSync;
XLSX.utils = utils;
XLSX.SSF = SSF;
